package com.example.adding;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    EditText Number1;
    EditText Number2;
    Button ADD_button;
    TextView Result;
    int ans=0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Toast.makeText(MainActivity.this, "onCreate is called", Toast.LENGTH_SHORT).show();

        Number1=findViewById(R.id.Number1);
        Number2=findViewById(R.id.Number2);
        ADD_button=findViewById(R.id.ADD);
        Result= findViewById(R.id.Result);



        ADD_button.setOnClickListener((v)->{

                double num1=Double.parseDouble(Number1.getText().toString());
                double num2=Double.parseDouble(Number2.getText().toString());
                double sum=num1+num2;
                Result.setText(Double.toString(sum));

        });



    }
}